<?php
	echo "Iniciando PHP ";
?>
	<br/>
<?php	
	$nome = "Wanderson";
	
	echo $nome;
	
	echo "<hr/>";
	$sobrenome = " Santos";
	
	echo $sobrenome;
	
	$a = 20;
	$b = 10;
	
	$soma = $a + $b;
	$sub = $a - $b;
	$mul = $a * $b;
	$div = $a / $b;
	
	echo "<br/>Soma: ";
	echo $soma;
	echo "<br/><b>Subtra��o:</b> ";
	echo $sub;
	echo "<br/><i>Multiplica��o:</i> ";
	echo $mul;
	echo "<br/><u>Divis�o:</u> ";
	echo $div;
	
	
	
	
	
	
?>