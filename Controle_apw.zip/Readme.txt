Todas as entidades est�o na pasta zipada , controle_DB que encontra-se na raiz.

Lista de integrantes 

Fl�vio de Arruda Ribeiro 201610271
Rayane Marques Cavalcanti 201612062
Anderson Barreto Ribeiro 201620220

