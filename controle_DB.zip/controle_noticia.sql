CREATE DATABASE  IF NOT EXISTS `controle` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `controle`;
-- MySQL dump 10.13  Distrib 5.6.23, for Win64 (x86_64)
--
-- Host: localhost    Database: controle
-- ------------------------------------------------------
-- Server version	5.6.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `noticia`
--

DROP TABLE IF EXISTS `noticia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `noticia` (
  `cod_noticia` int(11) NOT NULL AUTO_INCREMENT,
  `data_noticia` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `noticia` varchar(100) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  PRIMARY KEY (`cod_noticia`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `noticia`
--

LOCK TABLES `noticia` WRITE;
/*!40000 ALTER TABLE `noticia` DISABLE KEYS */;
INSERT INTO `noticia` VALUES (3,'2016-08-19 17:28:47','Definição do Escope de trabalho','Em grupo foram definidas as funções de cada um dos componentes do grupo de trabalho para criação do SCTM'),(4,'2016-08-19 17:28:47','Criação do modelo conceitual','Criação de um modelo conceitual do SCTM , conforme origentação e subsidiada pela aula de Banco de Dados'),(5,'2016-08-19 17:29:05','Importação do cadastro telefone','Foi efetuada importação de todo cadastro de produto hora ativo ou inativo da corporação , para tanto , foi entregue pela controladoria planilha com estas informações , onde foi importada para base de dados controle.'),(6,'2016-08-19 17:39:23','Documentação','Definida Rayane , para que seja documentadora do projeto assim como todos os dispositivos funcionais e não funcionais do trabalho'),(8,'2016-08-23 16:28:28','Criação de formulários              ','Foi entregue pelo Anderson , padrão de formulários juntamente com seu CSS , a ser aplicado como padrão em todas as páginas onde contenham estes dispositivo'),(10,'2016-08-24 13:54:16','Finalização de pesquisa de telefone ','Foi finalizado pelo Flávio tela de pesquisa dos números telefônicos ora ativos ou inativos, com query dinâmicas , tratadas em tempo de execução pelo numero ou pela descrição de seu usuario'),(13,'2016-09-13 00:09:24','Modificacoes template formularios','Foi realizado configuração no formulário , com titulo , imagem no rodape'),(14,'2016-09-27 22:26:19','Correção de validação com md5','Foi corrigido o processo de validação da senha de login , para que seja utilizado criptografia em md5.'),(15,'2016-09-28 11:47:27','Correção (Cadastro Funcionario)','Foi detectado Anderson que nao havia sido incluso variavel $privilegio na clausula submit, ocasionando falha na query de insercao.'),(16,'2016-11-11 16:36:00','Correcao (Cadastro Contrato)   ','   Foi corrigido o formulario de cadastro de Contrato, ora, com problemas no evento post   ');
/*!40000 ALTER TABLE `noticia` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-28 15:08:25
